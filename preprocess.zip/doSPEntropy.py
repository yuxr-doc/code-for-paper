import numpy as np
import pandas as pd
import os
from tkinter import Tk, filedialog
from tqdm import tqdm

# ======================
# 配置参数
# ======================
SAMPLE_RATE = 200  # 采样率200Hz
TARGET_COLUMNS = ['COM3-ACC', 'COM5-ACC', 'COM7-ACC', 'COM3-ANG', 'COM5-ANG', 'COM7-ANG']  # 六列时序数据名称
INVALID_DEVICES = ['COM12', 'COM12_115200']  # 需要排除的设备名称
M = 2  # 样本熵参数：嵌入维数
R = 0.2  # 样本熵参数：容限系数（通常取0.1-0.25倍标准差）


# ======================
# 样本熵计算函数
# ======================
def sample_entropy(U, m, r):
    """计算时间序列的样本熵（排除自匹配）"""
    N = len(U)
    if N < m + 2:
        return np.nan

    def _maxdist(x_i, x_j):
        """计算两个向量的切比雪夫距离"""
        return max([abs(ua - va) for ua, va in zip(x_i, x_j)])

    # 生成m维向量序列
    x_m = [U[i:i+m] for i in range(N - m + 1)]
    # 生成m+1维向量序列
    x_m1 = [U[i:i+m+1] for i in range(N - m)]

    # 计算匹配数（排除自身）
    def _count_matches(vectors):
        n_vec = len(vectors)
        if n_vec < 2:
            return 0
        total = 0
        for i in range(n_vec):
            for j in range(n_vec):
                if i != j and _maxdist(vectors[i], vectors[j]) <= r:
                    total += 1
        return total

    B = _count_matches(x_m)   # m维匹配对数
    A = _count_matches(x_m1)  # m+1维匹配对数

    total_pairs_m = len(x_m) * (len(x_m) - 1)
    total_pairs_m1 = len(x_m1) * (len(x_m1) - 1)

    if total_pairs_m == 0 or total_pairs_m1 == 0 or B == 0 or A == 0:
        return np.nan

    return -np.log(A / B)


def extract_features_for_sheet(df, sheet_name):
    """处理单个sheet的特征提取（计算样本熵）"""
    results = {}

    # 检查目标列是否存在
    missing_cols = [col for col in TARGET_COLUMNS if col not in df.columns]
    if missing_cols:
        print(f"警告: Sheet '{sheet_name}' 缺少以下列: {', '.join(missing_cols)}")
        return None

    # 记录原始行数
    original_rows = len(df)

    # 仅在存在'设备名称'列时进行设备过滤
    if '设备名称' in df.columns:
        # 过滤无效设备行
        valid_mask = ~df['设备名称'].isin(INVALID_DEVICES)
        df = df[valid_mask].reset_index(drop=True)
        removed_count = original_rows - len(df)
    else:
        # 没有设备名称列时不进行过滤
        removed_count = 0
        print(f"  - 缺少'设备名称'列，使用全部数据")

    print(f"\nSheet '{sheet_name}' 时序数据:")
    print(f"  - 原始数据行数: {original_rows}")

    # 仅在进行了过滤时才显示过滤信息
    if '设备名称' in df.columns and removed_count > 0:
        print(f"  - 移除无效设备行数: {removed_count} (设备名称为 {INVALID_DEVICES})")

    print(f"  - 有效数据行数: {len(df)}")

    # 显示时序长度
    print(f"各列有效数据点: ", end="")
    for col in TARGET_COLUMNS:
        valid_count = df[col].dropna().count()
        print(f"{col}: {valid_count}点", end=" | ")
    print()

    # 遍历每一列时序数据
    for col_name in TARGET_COLUMNS:
        # 获取当前列数据
        ts_data = df[col_name].dropna().values

        # 检查数据长度
        if len(ts_data) < 10:
            print(f"警告: Sheet '{sheet_name}' 列 {col_name} 数据不足 ({len(ts_data)}个点)")
            results[f"{col_name}_SampEn"] = np.nan
            continue

        # 计算容限值（R倍标准差）
        r_val = R * np.std(ts_data)

        # 计算样本熵
        try:
            sampen = sample_entropy(ts_data, M, r_val)
            results[f"{col_name}_SampEn"] = sampen
            if np.isnan(sampen):
                print(f"  - 列 {col_name} 样本熵: NaN (匹配对不足或数据过短)")
            else:
                print(f"  - 列 {col_name} 样本熵: {sampen:.4f} (m={M}, r={r_val:.4f})")
        except Exception as e:
            print(f"Sheet '{sheet_name}' 列 {col_name} 样本熵计算失败: {str(e)}")
            results[f"{col_name}_SampEn"] = np.nan

    # 将结果转换为DataFrame
    return pd.DataFrame([results])


# ======================
# 主处理流程
# ======================
def process_features():
    """处理Excel文件中的所有Sheet"""
    # 创建Tk根窗口
    root = Tk()
    root.withdraw()

    # 选择输入文件
    print("请选择Excel输入文件...")
    input_path = filedialog.askopenfilename(
        title="选择Excel文件",
        filetypes=[("Excel文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
    )

    if not input_path:
        print("未选择文件，程序退出")
        return

    try:
        # 创建输出路径
        output_dir = os.path.dirname(input_path)
        base_name = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}_SampleEntropy.xlsx")

        # 读取Excel文件
        print(f"\n处理文件: {os.path.basename(input_path)}")
        excel_file = pd.ExcelFile(input_path)
        sheet_names = excel_file.sheet_names

        # 显示文件基本信息
        print(f"文件包含 {len(sheet_names)} 个Sheet")
        print(f"将排除设备名称: {INVALID_DEVICES}")
        print(f"样本熵参数: m={M}, r={R}倍标准差")
        print("=" * 70)

        # 创建结果汇总DataFrame
        summary_df = pd.DataFrame()

        # 创建Excel写入器
        with pd.ExcelWriter(output_path) as writer:
            success_count = 0
            pbar = tqdm(sheet_names, desc="处理工作表中", unit="sheet")

            for sheet_name in pbar:
                pbar.set_postfix_str(sheet_name)

                try:
                    # 读取sheet数据（保留原始列名）
                    df = pd.read_excel(excel_file, sheet_name=sheet_name)

                    # 显示sheet基本信息
                    print(f"\n处理Sheet '{sheet_name}'...")
                    print(f"  - 原始数据形状: {df.shape[0]}行 × {df.shape[1]}列")

                    # 检查列名
                    if '设备名称' in df.columns:
                        # 统计各设备类型数量
                        device_counts = df['设备名称'].value_counts()
                        print("  - 设备类型统计:")
                        for device, count in device_counts.items():
                            status = "有效" if device not in INVALID_DEVICES else "无效"
                            print(f"      {device}: {count}行 ({status})")
                    else:
                        print("  - 警告: 缺少'设备名称'列")

                    # 计算样本熵
                    features_df = extract_features_for_sheet(df, sheet_name)

                    if features_df is None or features_df.empty:
                        print(f"× 处理失败: {sheet_name}")
                        continue

                    # 添加Sheet名称列
                    features_df.insert(0, 'Sheet名称', sheet_name)

                    # 显示提取的特征信息
                    print(f"  - 计算完成: {len(features_df.columns) - 1}个样本熵值")

                    # 保存到Excel（保留原始sheet名称）
                    features_df.to_excel(writer, sheet_name=sheet_name[:30], index=False)

                    # 添加到汇总
                    summary_df = pd.concat([summary_df, features_df], ignore_index=True)

                    success_count += 1
                    print(f"√ 已完成: {sheet_name}")

                except Exception as e:
                    print(f"处理 '{sheet_name}' 时出错: {str(e)}")

            # 保存汇总结果
            if not summary_df.empty:
                summary_df.to_excel(writer, sheet_name="汇总结果", index=False)

        # 结果汇总
        print(f"\n{'=' * 70}")
        print(f"处理完成! 成功处理 {success_count}/{len(sheet_names)} 个Sheet")
        print(f"结果保存至: {output_path}")
        print(f"样本熵参数: m={M}, r={R}倍标准差")
        print(f"排除设备: {INVALID_DEVICES}")

    except Exception as e:
        print(f"\n处理过程中出错: {str(e)}")


# ======================
# 执行程序
# ======================
if __name__ == "__main__":
    print("=" * 70)
    print("时序数据样本熵计算工具")
    print("=" * 70)
    print(f"配置说明:")
    print(f"- 采样率: {SAMPLE_RATE}Hz")
    print(f"- 目标数据列: {TARGET_COLUMNS}")
    print(f"- 样本熵参数: m={M}, r={R}倍标准差")
    print(f"- 排除设备: {INVALID_DEVICES}")
    process_features()