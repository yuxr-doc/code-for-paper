import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import FastICA
from sklearn.preprocessing import StandardScaler

# ======================
# 参数配置区（用户可调整）
# ======================
ICA_PARAMS = {
    'n_components': 4,  # 提取成分数
    'algorithm': 'parallel',  # 算法类型：parallel/deflation
    'whiten': 'arbitrary-variance',  # 是否白化数据{'arbitrary-variance', 'unit-variance'}
    'fun': 'exp',  # 非线性函数：logcosh/cube/exp
    'max_iter': 500,  # 最大迭代次数
    'tol': 0.0001  # 收敛阈值
}
PLOT_PARAMS = {
    'figsize': (12, 8),  # 图表尺寸
    'component_colors': ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']  # 成分颜色
}


# ======================
# ICA处理函数
# ======================
def process_sheet(data, sheet_name):
    """处理单个Sheet的ICA流程"""
    # 0. 统一列名为字符串（sklearn要求）
    data.columns = data.columns.astype(str)

    # 1. 数据标准化
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(data)

    # 2. 执行ICA
    ica = FastICA(**ICA_PARAMS, random_state=42)
    components = ica.fit_transform(scaled_data)

    # 3. 计算混合矩阵
    mixing_matrix = ica.mixing_

    # 3.5. 计算各IC与电梯平台信号的相关性
    elevator_signal = data.iloc[:, 3].values  # 第4列为电梯平台
    print(f"\n  [{sheet_name}] IC-平台相关性 (Pearson r):")
    for i in range(components.shape[1]):
        corr = np.corrcoef(components[:, i], elevator_signal)[0, 1]
        print(f"    IC{i}: r = {corr:.4f}")

    # 4. 可视化成分
    fig = visualize_components(components, sheet_name)

    # 5. 用户交互选择
    remove_idx = get_user_selection(components.shape[1])

    # 6. 重建信号（剔除选定成分）
    modified_components = components.copy()
    modified_components[:, remove_idx] = 0  # 置零被删除成分
    reconstructed = ica.inverse_transform(modified_components)

    # 7. 反标准化
    final_data = scaler.inverse_transform(reconstructed)

    return pd.DataFrame(final_data, columns=data.columns, index=data.index), fig


# ======================
# 可视化函数
# ======================
def visualize_components(components, title):
    """绘制独立成分时序图"""
    plt.figure(figsize=PLOT_PARAMS['figsize'])
    for i in range(components.shape[1]):
        plt.plot(components[:, i],
                 color=PLOT_PARAMS['component_colors'][i % 4],
                 linewidth=1.5,
                 label=f'Component {i}')

    plt.title(f'Independent Components - {title}', fontsize=14)
    plt.xlabel('Time Points', fontsize=12)
    plt.ylabel('Amplitude', fontsize=12)
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.show()
    return plt.gcf()


# ======================
# 用户交互函数
# ======================
def get_user_selection(num_components):
    """获取用户要删除的成分索引"""
    print(f"\n当前成分数量: {num_components}")
    print("请查看弹出的成分图，输入需要删除的成分编号 (0开始)，多个用逗号分隔")
    print("示例: 删除成分0和2 -> 输入: 0,2\n")

    while True:
        try:
            selection = input("请输入要删除的成分编号 (直接回车保留全部): ")
            if not selection.strip():
                return []

            indices = [int(idx) for idx in selection.split(',')]
            if all(0 <= idx < num_components for idx in indices):
                return indices
            print(f"错误: 请输入0-{num_components - 1}之间的有效编号")
        except ValueError:
            print("错误: 请输入逗号分隔的数字 (如: 0,2)")


# ======================
# 主处理流程
# ======================
def process_excel_ica(input_path, output_path):
    """处理Excel所有Sheet"""
    # 读取所有Sheet
    sheets = pd.read_excel(input_path, sheet_name=None)

    with pd.ExcelWriter(output_path) as writer:
        for sheet_name, df in sheets.items():
            print(f"\n处理Sheet: {sheet_name}")

            # 验证数据格式
            if len(df.columns) != 4:
                print(f"! 警告: {sheet_name} 包含 {len(df.columns)} 列，需要4列时序数据(3个身体部位+1列电梯)，已跳过")
                df.to_excel(writer, sheet_name=sheet_name, index=False)
                continue

            # 执行ICA处理
            result_df, fig = process_sheet(df, sheet_name)

            # 保存结果和图像
            result_df.to_excel(writer, sheet_name=sheet_name, index=False)
            fig.savefig(f"{sheet_name}_components.png")
            plt.close(fig)

            print(f"√ 已完成: {sheet_name} - 结果已保存")

    print(f"\n处理完成! 结果保存至: {output_path}")
    print(f"各成分图已保存为PNG文件")


# ======================
# 执行示例
# ======================
if __name__ == "__main__":
    # 配置路径
    INPUT_EXCEL = "input_data.xlsx"  # 输入文件
    OUTPUT_EXCEL = "ica_results.xlsx"  # 输出文件

    # 启动处理流程
    process_excel_ica(INPUT_EXCEL, OUTPUT_EXCEL)
