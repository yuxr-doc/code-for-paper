#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IMU–BIOPAC同步数据采集程序

功能（对应论文 Methods §2.1–2.2）：
1. 从四个IMU蓝牙串口接收数据（1 kHz），IMU型号 WitMotion WT9011G4K。
2. 每100 ms（10 Hz）将四路数据按硬件时间戳排序，分配同步时间戳。
3. 同一同步时间戳通过UDP发送至 AcqKnowledge 5.5，用于离线对齐。
4. 每个100 ms窗口期望100帧/IMU；缺帧线性插值，冗余帧均匀抽取（decimation）。
5. 窗口数据保存为CSV。
"""

import serial
import threading
import queue
import time
import socket
import csv
import os
import numpy as np
from datetime import datetime
from collections import deque

# ===================== 用户配置区域 =====================
# 四个IMU的蓝牙串口（COM口），对应论文中的解剖位置
# RTEMP: 右颞部（头部），L5: 第五腰椎（躯干），RFH: 右腓骨头（小腿），Platform: 电梯平台
IMU_PORTS = {
    'RTEMP':    'COM3',
    'L5':       'COM5',
    'RFH':      'COM7',
    'Platform': 'COM12'
}
BAUDRATE = 921600       # WT9011G4K 默认波特率（4路×1kHz需 ≥460800）
TIMEOUT = 1

# 数据解析函数（WitMotion WT9011G4K 输出示例：时间戳,ax,ay,az,wx,wy,wz,angX,angY,angZ）
# 请根据IMU实际输出格式修改
def parse_imu_line(line):
    """将一行字符串解析为 (timestamp, data_list)"""
    parts = line.strip().split(',')
    if len(parts) >= 10:
        try:
            timestamp = float(parts[0])
            data = [float(x) for x in parts[1:10]]
            return timestamp, data
        except ValueError:
            return None, None
    return None, None

# AcqKnowledge UDP 同步配置
SYNC_UDP_IP = '127.0.0.1'
SYNC_UDP_PORT = 12345

# 数据保存路径
SAVE_DIR = './imu_data'
if not os.path.exists(SAVE_DIR):
    os.makedirs(SAVE_DIR)

# 每100 ms窗口期望帧数（1 kHz × 0.1 s = 100）
EXPECTED_FRAMES_PER_WINDOW = 100
WINDOW_DURATION = 0.1  # 秒

# ===================== 全局数据结构 =====================
# buffer 存储 (arrival_time, imu_timestamp, data_list)
# arrival_time: PC 接收时刻，用于窗口切分
# imu_timestamp: IMU 硬件时间戳，用于 CSV 记录和帧内排序
imu_queues = {imu: queue.Queue() for imu in IMU_PORTS}
imu_buffer = {imu: deque() for imu in IMU_PORTS}
buffer_locks = {imu: threading.Lock() for imu in IMU_PORTS}
segment_counter = 0

# ===================== 串口读取线程 =====================
def serial_reader(imu_name, port):
    """持续读取指定串口，将原始行放入对应队列"""
    try:
        ser = serial.Serial(port, BAUDRATE, timeout=TIMEOUT)
        print(f"[{imu_name}] 已打开串口 {port}")
        while True:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            if line:
                # 记录 PC 到达时间，与原始行一并入队
                imu_queues[imu_name].put((time.time(), line))
    except Exception as e:
        print(f"[{imu_name}] 串口错误: {e}")
    finally:
        if 'ser' in locals() and ser.is_open:
            ser.close()

# ===================== 数据缓冲处理线程 =====================
def process_imu_queue(imu_name):
    """从队列取出数据，解析并按 arrival_time 排序存入 buffer"""
    q = imu_queues[imu_name]
    buffer = imu_buffer[imu_name]
    lock = buffer_locks[imu_name]
    while True:
        try:
            arrival_time, line = q.get(timeout=0.1)
        except queue.Empty:
            continue
        imu_ts, data = parse_imu_line(line)
        if imu_ts is None or data is None:
            continue
        with lock:
            # 按 arrival_time 插入（保证按 PC 接收时间排序）
            inserted = False
            for i, (at, _, _) in enumerate(buffer):
                if arrival_time < at:
                    buffer.insert(i, (arrival_time, imu_ts, data))
                    inserted = True
                    break
            if not inserted:
                buffer.append((arrival_time, imu_ts, data))
            max_buffer_len = 2000  # 保留约2秒数据
            while len(buffer) > max_buffer_len:
                buffer.popleft()

# ===================== 窗口完整性与重采样 =====================
def resample_window(points, target_n, window_start, window_end):
    """
    将窗口内数据重采样至 target_n 帧。
    - 缺帧: 线性插值补足（按均匀时间网格插值）
    - 冗余: 均匀抽取（decimation）
    - 恰好: 原样返回
    points: list of (arrival_time, imu_timestamp, data_list)
    返回: (imu_ts_array, data_matrix) 形状 (target_n,) 和 (target_n, n_features)
    """
    n = len(points)
    if n == 0:
        ts_grid = np.linspace(window_start, window_end, target_n, endpoint=False)
        return ts_grid, np.full((target_n, 9), np.nan)

    ts_arr = np.array([p[1] for p in points])       # IMU 硬件时间戳
    data_arr = np.array([p[2] for p in points])

    if n == target_n:
        return ts_arr, data_arr

    ts_grid = np.linspace(window_start, window_end, target_n, endpoint=False)

    if n < target_n:
        # 缺帧 → 基于 PC 到达时间的线性插值
        arr_arr = np.array([p[0] for p in points])   # PC arrival times
        interp_data = np.zeros((target_n, data_arr.shape[1]))
        for feat in range(data_arr.shape[1]):
            interp_data[:, feat] = np.interp(ts_grid, arr_arr, data_arr[:, feat])
        return ts_grid, interp_data
    else:
        # 冗余帧 → 均匀抽取
        indices = np.linspace(0, n - 1, target_n, dtype=int)
        return ts_arr[indices], data_arr[indices]

# ===================== 同步 + 分段保存（10 Hz，论文核心逻辑） =====================
def sync_and_save_loop():
    """
    每100 ms执行一次：
    1. 生成同步时间戳
    2. 提取各IMU当前窗口数据（按 PC 到达时间划分窗口）
    3. 同一时间戳通过UDP发送至AcqKnowledge
    4. 重采样至精确100帧/窗口
    5. 保存
    """
    global segment_counter
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    next_window_time = time.time() + WINDOW_DURATION

    while True:
        now = time.time()
        if now >= next_window_time:
            # —— 步骤1: 生成本窗口同步时间戳 ——
            sync_timestamp = now
            window_end = sync_timestamp
            window_start = window_end - WINDOW_DURATION

            # —— 步骤2: 提取各IMU窗口内数据（按 PC 到达时间划分） ——
            segment_data = {}
            window_summary = {}
            for imu in IMU_PORTS:
                buffer = imu_buffer[imu]
                lock = buffer_locks[imu]
                with lock:
                    window_points = []
                    for arrival_time, imu_ts, data in buffer:
                        if window_start <= arrival_time < window_end:
                            window_points.append((arrival_time, imu_ts, data))
                        elif arrival_time >= window_end:
                            break
                    segment_data[imu] = window_points
                    window_summary[imu] = len(window_points)

            # —— 步骤3: 同一时间戳通过UDP发送至AcqKnowledge ——
            msg = f"{sync_timestamp:.6f}\n".encode()
            sock.sendto(msg, (SYNC_UDP_IP, SYNC_UDP_PORT))

            # —— 步骤4: 重采样至精确100帧/窗口 ——
            resampled_data = {}
            for imu, points in segment_data.items():
                ts_grid, data_grid = resample_window(
                    points, EXPECTED_FRAMES_PER_WINDOW, window_start, window_end
                )
                resampled_data[imu] = (ts_grid, data_grid)

            # —— 步骤5: 保存 ——
            save_segment(resampled_data, segment_counter, sync_timestamp)

            # 日志
            raw_counts = " | ".join(f"{imu}:{window_summary[imu]}fr" for imu in IMU_PORTS)
            print(f"[seg {segment_counter:04d}] sync_ts={sync_timestamp:.6f} | {raw_counts}")

            segment_counter += 1
            next_window_time += WINDOW_DURATION  # 对齐到固定时间网格，防止漂移
        time.sleep(0.001)

def save_segment(resampled_data, seg_idx, sync_timestamp):
    """保存重采样后的窗口数据"""
    ts_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    for imu, (imu_ts_grid, data_grid) in resampled_data.items():
        filename = os.path.join(SAVE_DIR, f"{imu}_{ts_str}_seg{seg_idx:04d}.csv")
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'sync_timestamp', 'frame_timestamp',
                'ax', 'ay', 'az',
                'wx', 'wy', 'wz',
                'ang_x', 'ang_y', 'ang_z'
            ])
            for i in range(len(imu_ts_grid)):
                writer.writerow(
                    [f"{sync_timestamp:.6f}", f"{imu_ts_grid[i]:.6f}"] +
                    [f"{data_grid[i][j]:.6f}" if not np.isnan(data_grid[i][j]) else 'NaN'
                     for j in range(data_grid.shape[1])]
                )

# ===================== 主程序 =====================
def main():
    # 启动串口读取线程（每个IMU一个）
    for imu, port in IMU_PORTS.items():
        t = threading.Thread(target=serial_reader, args=(imu, port), daemon=True)
        t.start()
        p = threading.Thread(target=process_imu_queue, args=(imu,), daemon=True)
        p.start()

    # 启动同步+保存线程
    sync_thread = threading.Thread(target=sync_and_save_loop, daemon=True)
    sync_thread.start()

    print("=" * 60)
    print("IMU–BIOPAC 同步采集已启动")
    print(f"  IMU配置: {IMU_PORTS}")
    print(f"  波特率: {BAUDRATE}")
    print(f"  窗口: {WINDOW_DURATION*1000:.0f} ms, 期望 {EXPECTED_FRAMES_PER_WINDOW} 帧/IMU")
    print(f"  UDP同步: {SYNC_UDP_IP}:{SYNC_UDP_PORT}")
    print("  按 Ctrl+C 退出")
    print("=" * 60)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n程序退出")

if __name__ == "__main__":
    main()
