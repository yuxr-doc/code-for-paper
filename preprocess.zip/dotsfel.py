import pandas as pd
import tsfel
import os
from tkinter import Tk, filedialog
from tqdm import tqdm

# ======================
# 配置参数
# ======================
FEATURE_CONFIG = tsfel.get_features_by_domain()  # 获取所有可用特征配置
SAMPLE_RATE = 200  # 采样率200Hz
TARGET_COLUMNS = ['COM3-ACC', 'COM5-ACC', 'COM7-ACC', 'COM3-ANG', 'COM5-ANG', 'COM7-ANG']  # 六列时序数据名称
INVALID_DEVICES = ['COM12', 'COM12_115200']  # 需要排除的设备名称


# ======================
# 特征提取函数
# ======================
def extract_features_for_sheet(df, sheet_name):
    """处理单个sheet的特征提取"""
    results = pd.DataFrame()

    # 检查目标列是否存在
    missing_cols = [col for col in TARGET_COLUMNS if col not in df.columns]
    if missing_cols:
        print(f"警告: Sheet '{sheet_name}' 缺少以下列: {', '.join(missing_cols)}")
        return None

    # 检查设备名称列是否存在
    if '设备名称' not in df.columns:
        print(f"警告: Sheet '{sheet_name}' 缺少'设备名称'列，无法过滤无效设备")
        return None

    # 过滤无效设备行
    original_rows = len(df)
    valid_mask = ~df['设备名称'].isin(INVALID_DEVICES)
    df = df[valid_mask].reset_index(drop=True)
    removed_count = original_rows - len(df)

    print(f"\nSheet '{sheet_name}' 时序数据:")
    print(f"  - 原始数据行数: {original_rows}")
    print(f"  - 移除无效设备行数: {removed_count} (设备名称为 {INVALID_DEVICES})")
    print(f"  - 有效数据行数: {len(df)}")

    # 显示时序长度
    print(f"各列有效数据点: ", end="")
    for col in TARGET_COLUMNS:
        valid_count = df[col].dropna().count()
        print(f"{col}: {valid_count}点", end=" | ")
    print()

    # 遍历每一列时序数据
    for col_name in TARGET_COLUMNS:
        # 获取当前列数据
        ts_data = df[col_name].dropna().values

        # 检查数据长度
        if len(ts_data) < 10:
            print(f"警告: Sheet '{sheet_name}' 列 {col_name} 数据不足 ({len(ts_data)}个点)")
            continue

        # 提取特征
        try:
            features = tsfel.time_series_features_extractor(
                FEATURE_CONFIG,
                ts_data,
                fs=SAMPLE_RATE,
                window_size=len(ts_data)
            )

            # 添加列名前缀
            features = features.add_prefix(f"{col_name}_")

            # 添加到结果
            if results.empty:
                results = features
            else:
                results = pd.concat([results, features], axis=1)

        except Exception as e:
            print(f"Sheet '{sheet_name}' 列 {col_name} 特征提取失败: {str(e)}")

    return results


# ======================
# 主处理流程
# ======================
def process_features():
    """处理Excel文件中的所有Sheet"""
    # 创建Tk根窗口
    root = Tk()
    root.withdraw()

    # 选择输入文件
    print("请选择Excel输入文件...")
    input_path = filedialog.askopenfilename(
        title="选择Excel文件",
        filetypes=[("Excel文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
    )

    if not input_path:
        print("未选择文件，程序退出")
        return

    try:
        # 创建输出路径
        output_dir = os.path.dirname(input_path)
        base_name = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}_Features.xlsx")

        # 读取Excel文件
        print(f"\n处理文件: {os.path.basename(input_path)}")
        excel_file = pd.ExcelFile(input_path)
        sheet_names = excel_file.sheet_names

        # 显示文件基本信息
        print(f"文件包含 {len(sheet_names)} 个Sheet")
        print(f"将排除设备名称: {INVALID_DEVICES}")
        print("=" * 70)

        # 创建Excel写入器
        with pd.ExcelWriter(output_path) as writer:
            success_count = 0
            pbar = tqdm(sheet_names, desc="处理工作表中", unit="sheet")

            for sheet_name in pbar:
                pbar.set_postfix_str(sheet_name)

                try:
                    # 读取sheet数据（保留原始列名）
                    df = pd.read_excel(excel_file, sheet_name=sheet_name)

                    # 显示sheet基本信息
                    print(f"\n处理Sheet '{sheet_name}'...")
                    print(f"  - 原始数据形状: {df.shape[0]}行 × {df.shape[1]}列")

                    # 检查列名
                    if '设备名称' in df.columns:
                        # 统计各设备类型数量
                        device_counts = df['设备名称'].value_counts()
                        print("  - 设备类型统计:")
                        for device, count in device_counts.items():
                            status = "有效" if device not in INVALID_DEVICES else "无效"
                            print(f"      {device}: {count}行 ({status})")
                    else:
                        print("  - 警告: 缺少'设备名称'列")

                    # 提取特征
                    features_df = extract_features_for_sheet(df, sheet_name)

                    if features_df is None or features_df.empty:
                        print(f"× 处理失败: {sheet_name}")
                        continue

                    # 显示提取的特征信息
                    print(f"  - 提取特征数量: {features_df.shape[1]}个")
                    print(f"  - 特征数据形状: {features_df.shape[0]}行 × {features_df.shape[1]}列")

                    # 保存到Excel（保留原始sheet名称）
                    features_df.to_excel(writer, sheet_name=sheet_name[:30], index=False)
                    success_count += 1
                    print(f"√ 已完成: {sheet_name}")

                except Exception as e:
                    print(f"处理 '{sheet_name}' 时出错: {str(e)}")

        # 结果汇总
        print(f"\n{'=' * 70}")
        print(f"处理完成! 成功处理 {success_count}/{len(sheet_names)} 个Sheet")
        print(f"结果保存至: {output_path}")
        print(f"特征计算已排除设备名称: {INVALID_DEVICES}")

    except Exception as e:
        print(f"\n处理过程中出错: {str(e)}")


# ======================
# 执行程序
# ======================
if __name__ == "__main__":
    print("=" * 70)
    print("时序特征提取工具 (TSFEL)")
    print("=" * 70)
    print(f"配置说明:")
    print(f"- 采样率: {SAMPLE_RATE}Hz")
    print(f"- 目标数据列: {TARGET_COLUMNS}")
    print(f"- 排除设备: {INVALID_DEVICES}")
    process_features()