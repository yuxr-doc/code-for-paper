import pandas as pd
import os
from tkinter import Tk, filedialog
from openpyxl import load_workbook


def process_change_points():
    """处理变更点标记数据"""
    # 创建Tk根窗口
    root = Tk()
    root.withdraw()

    # 选择输入文件
    print("请选择包含变更点标记的Excel文件...")
    input_path = filedialog.askopenfilename(
        title="选择Excel文件",
        filetypes=[("Excel文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
    )

    if not input_path:
        print("未选择文件，程序退出")
        return

    try:
        # 创建输出路径
        output_dir = os.path.dirname(input_path)
        base_name = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}_Segmented.xlsx")

        # 读取Excel文件
        print(f"\n处理文件: {os.path.basename(input_path)}")
        df = pd.read_excel(input_path)

        # 检查是否存在变更点列
        if 'ChangePoint_Position' not in df.columns:
            print("错误: 文件中未找到 'ChangePoint_Position' 列")
            return

        # 获取变更点位置
        change_points = df[df['ChangePoint_Position'].notna()].index.tolist()

        if len(change_points) < 2:
            print("错误: 至少需要两个变更点才能进行分割")
            return

        print(f"找到 {len(change_points)} 个变更点位置")
        print("=" * 70)

        # 创建Excel写入器
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # 处理每个区间
            for i in range(len(change_points) - 1):
                start_idx = change_points[i]
                end_idx = change_points[i + 1]

                # 提取区间数据
                segment_df = df.iloc[start_idx:end_idx + 1]
                segment_name = f"Segment_{i + 1}"

                # 显示信息
                segment_length = len(segment_df)
                print(f"创建 {segment_name}: 从行 {start_idx} 到 {end_idx}, 包含 {segment_length} 行数据")

                # 保存到新sheet
                segment_df.to_excel(writer, sheet_name=segment_name, index=False)

        # 结果汇总
        print("\n" + "=" * 70)
        print(f"处理完成! 共创建 {len(change_points) - 1} 个数据段")
        print(f"结果保存至: {output_path}")

    except Exception as e:
        print(f"\n处理过程中出错: {str(e)}")


# ======================
# 执行程序
# ======================
if __name__ == "__main__":
    print("=" * 70)
    print("变更点数据分割工具")
    print("=" * 70)
    print("功能说明:")
    print("- 选择一个包含'ChangePoint_Position'列的Excel文件")
    print("- 程序将根据变更点标记分割数据")
    print("- 每两个标记之间的数据(包含标记行)将保存到单独的Sheet")
    print("=" * 70)
    process_change_points()
