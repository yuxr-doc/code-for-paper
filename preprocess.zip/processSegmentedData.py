import pandas as pd
import os
from tkinter import Tk, filedialog


def process_excel_sheets(input_file_path):
    """
    处理Excel文件中的所有sheet：
    1. 删除'设备名称'为COM12且'ChangePoint_Position'为空的行
    2. 对三个ANG列的数据进行基准值调整
    3. 统计并显示每个sheet中COM12的行数
    """
    # 读取所有sheet
    all_sheets = pd.read_excel(input_file_path, sheet_name=None)

    processed_sheets = {}

    for sheet_name, df in all_sheets.items():
        print(f"\n处理Sheet: {sheet_name}")

        # 记录原始行数
        original_rows = len(df)

        # 统计并显示COM12的行数
        com12_rows = df[df['设备名称'] == 'COM12']
        print(f"设备名称为COM12的行数: {len(com12_rows)}")

        # 步骤1: 删除'设备名称'为COM12且'ChangePoint_Position'为空的行
        # 创建删除条件
        condition = (df['设备名称'] == 'COM12') & (df['ChangePoint_Position'].isnull())
        df = df[~condition]

        # 步骤2: 对ANG列进行基准值调整
        ang_columns = ['COM3-ANG', 'COM5-ANG', 'COM7-ANG']

        # 获取非COM12行的第一行索引
        valid_first_index = df[df['设备名称'] != 'COM12'].index[0]

        for col in ang_columns:
            # 获取基准值（非COM12行的第一行值）
            base_value = df.at[valid_first_index, col]

            # 对非COM12行进行基准值调整
            non_com12_mask = df['设备名称'] != 'COM12'
            df.loc[non_com12_mask, col] = df.loc[non_com12_mask, col] - base_value

        # 记录处理结果
        processed_rows = len(df)
        print(f"处理完成: 删除{original_rows - processed_rows}行，保留{processed_rows}行")

        processed_sheets[sheet_name] = df

    return processed_sheets


def main():
    """主函数：处理Excel文件并保存结果"""
    # 创建Tk根窗口
    root = Tk()
    root.withdraw()

    # 选择输入文件
    print("请选择Excel输入文件...")
    input_path = filedialog.askopenfilename(
        title="选择Excel文件",
        filetypes=[("Excel文件", "*.xlsx"), ("所有文件", "*.*")]
    )

    if not input_path:
        print("未选择文件，程序退出")
        return

    try:
        # 处理所有sheet
        processed_data = process_excel_sheets(input_path)

        # 创建输出文件名
        output_dir = os.path.dirname(input_path)
        base_name = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}_processed.xlsx")

        # 保存处理结果到新Excel文件
        with pd.ExcelWriter(output_path) as writer:
            for sheet_name, df in processed_data.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False)

        print(f"\n处理完成! 结果已保存至: {output_path}")

    except Exception as e:
        print(f"处理过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
