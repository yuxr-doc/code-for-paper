"""
Confidence interval calculation for model evaluation metrics.

Methods (as described in the paper):
  - AUROC: DeLong's method (DeLong et al., 1988) — analytic, no resampling
  - Accuracy, Recall, Precision, F1: Wilson score interval (Wilson, 1927) — analytic
"""

import numpy as np
from scipy.stats import norm
from sklearn.metrics import roc_auc_score, confusion_matrix


# ============================================================
# DeLong's method for AUROC
# ============================================================

def delong_ci(y_true, y_score, confidence=0.95):
    """
    DeLong's method for AUROC variance estimation.

    DeLong, E. R., DeLong, D. M., & Clarke-Pearson, D. L. (1988).
    Comparing the Areas under Two or More Correlated Receiver
    Operating Characteristic Curves: A Nonparametric Approach.
    Biometrics, 44(3), 837–845.

    Parameters:
        y_true: ground truth binary labels, shape (n_samples,)
        y_score: predicted probabilities for the positive class, shape (n_samples,)
        confidence: confidence level (default 0.95)

    Returns:
        dict with keys: auroc, ci_lower, ci_upper, se
    """
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)

    pos_mask = y_true == 1
    neg_mask = y_true == 0

    n_pos = np.sum(pos_mask)
    n_neg = np.sum(neg_mask)

    if n_pos == 0 or n_neg == 0:
        raise ValueError("y_true must contain both positive and negative samples.")

    scores_pos = y_score[pos_mask]
    scores_neg = y_score[neg_mask]

    # Vectorized structural components (placements)
    # For each positive vs all negatives
    # shape: (n_pos, n_neg)
    s_pos = scores_pos.reshape(-1, 1)
    s_neg = scores_neg.reshape(1, -1)

    # I(s_pos > s_neg) + 0.5 * I(s_pos == s_neg)
    comp = (s_pos > s_neg).astype(float) + 0.5 * (s_pos == s_neg).astype(float)

    V10 = comp.mean(axis=1)  # (n_pos,) — per-positive-sample placement
    V01 = comp.mean(axis=0)  # (n_neg,) — per-negative-sample placement

    auc_value = np.mean(V10)  # = np.mean(V01)

    # DeLong variance estimator
    var_V10 = np.var(V10, ddof=1) / n_pos
    var_V01 = np.var(V01, ddof=1) / n_neg
    se = np.sqrt(var_V10 + var_V01)

    alpha = 1 - confidence
    z = norm.ppf(1 - alpha / 2)
    ci_lower = max(0.0, auc_value - z * se)
    ci_upper = min(1.0, auc_value + z * se)

    return {
        'auroc': auc_value,
        'ci_lower': ci_lower,
        'ci_upper': ci_upper,
        'se': se,
        'method': f"DeLong ({confidence*100:.0f}% CI)"
    }


# ============================================================
# Wilson score interval for binomial proportions
# ============================================================

def wilson_ci(k, n, confidence=0.95):
    """
    Wilson score interval for a binomial proportion.

    Wilson, E. B. (1927). Probable Inference, the Law of Succession,
    and Statistical Inference. JASA, 22(158), 209–212.

    Parameters:
        k: number of successes
        n: total number of trials
        confidence: confidence level (default 0.95)

    Returns:
        tuple: (ci_lower, ci_upper)
    """
    if n == 0:
        return (0.0, 1.0)

    p = k / n
    alpha = 1 - confidence
    z = norm.ppf(1 - alpha / 2)
    z2 = z ** 2

    denominator = 1 + z2 / n
    center = (p + z2 / (2 * n)) / denominator
    margin = z * np.sqrt((p * (1 - p) + z2 / (4 * n)) / n) / denominator

    ci_lower = max(0.0, center - margin)
    ci_upper = min(1.0, center + margin)

    return (ci_lower, ci_upper)


# ============================================================
# Metric-specific CI wrappers
# ============================================================

def compute_all_cis(y_true, y_pred, y_score, confidence=0.95):
    """
    Compute 95% CIs for all metrics from pooled predictions.

    Parameters:
        y_true: ground truth binary labels
        y_pred: binary predictions (thresholded)
        y_score: predicted probabilities
        confidence: confidence level

    Returns:
        dict with keys: accuracy, auroc, recall, precision, f1
        Each value is a dict: {value, ci_lower, ci_upper}
    """
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    y_score = np.asarray(y_score, dtype=float)

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    n = len(y_true)

    # AUROC via DeLong
    auroc_result = delong_ci(y_true, y_score, confidence)

    # Accuracy via Wilson: k = TP + TN, n = total
    acc_value = (tp + tn) / n
    acc_lo, acc_hi = wilson_ci(tp + tn, n, confidence)

    # Recall (sensitivity) via Wilson: k = TP, n = TP + FN = actual positives
    rec_value = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    rec_lo, rec_hi = wilson_ci(tp, tp + fn, confidence)

    # Precision (PPV) via Wilson: k = TP, n = TP + FP = predicted positives
    prec_value = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    prec_lo, prec_hi = wilson_ci(tp, tp + fp, confidence)

    # F1 via Wilson (treated as proportion with n = total samples)
    f1_value = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else 0.0
    f1_lo, f1_hi = wilson_ci(round(f1_value * n), n, confidence)

    return {
        'accuracy':  {'value': acc_value,  'ci_lower': acc_lo,  'ci_upper': acc_hi},
        'auroc':     {'value': auroc_result['auroc'], 'ci_lower': auroc_result['ci_lower'], 'ci_upper': auroc_result['ci_upper']},
        'recall':    {'value': rec_value,  'ci_lower': rec_lo,   'ci_upper': rec_hi},
        'precision': {'value': prec_value, 'ci_lower': prec_lo,  'ci_upper': prec_hi},
        'f1':        {'value': f1_value,   'ci_lower': f1_lo,    'ci_upper': f1_hi},
    }


def print_ci_report(results, title=None):
    """Pretty-print CI results."""
    if title:
        print(f"\n{'='*60}")
        print(f"  {title}")
        print(f"{'='*60}")

    for metric in ['auroc', 'accuracy', 'recall', 'precision', 'f1']:
        r = results[metric]
        print(f"  {metric.upper():<10}: {r['value']:.4f}  "
              f"(95% CI: {r['ci_lower']:.4f}-{r['ci_upper']:.4f})")


