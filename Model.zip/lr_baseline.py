import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, auc, brier_score_loss
from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
import optuna
import matplotlib.pyplot as plt
import shap
from matplotlib.gridspec import GridSpec
from pandas import json_normalize
from correct_auroc_bootstrap import compute_all_cis, print_ci_report

###################

def process_scores(scores):
    df = json_normalize(scores, meta=[
        'fold', 'accuracy', 'f1', 'recall', 'precision', 'roc_auc',
        'best_penalty', 'best_C', 'best_solver'
    ], sep='_')
    return df.rename(columns={
        'best_penalty': 'Best_Penalty',
        'best_C': 'Best_C',
        'best_solver': 'Best_Solver'
    })

# 数据提取
df = pd.read_excel(r"C:\Users\Yxr\Desktop\26-5-8使用代码\source data.xlsx", header=None, sheet_name="Sheet3", nrows=327 + 1)
header = df.iloc[0]
df = df[1:].astype('float32')
df.columns = header

feature_columns = [
    'ACC_13_Spectral entropy',
    'ANG_10_Mean',
    'ANG_13_SPEN',
]
feature_names = [
    'RTEMP_Acc_SpecEn',
    'RFH_Ang_Mean',
    'RTEMP_Ang_SpEn',
]
X = df[feature_columns]
tag = 'SCR Event3'
Y = df[tag].astype("int")
X_raw = df[feature_columns].values
Y_raw = df[tag].astype("int").values

# 数据提取 - 外部验证
df_ev = pd.read_excel(r"C:\Users\Yxr\Desktop\26-5-8使用代码\source data.xlsx", header=None, sheet_name="Sheet4", nrows=272 + 1)
header_ev = df_ev.iloc[0]
df_ev = df_ev[1:].astype('float32')
df_ev.columns = header_ev
X_raw_ev = df_ev[feature_columns].values
Y_raw_ev = df_ev[tag].astype("int").values

# 交叉验证
num_outcv = 5
num_inncv = 5
num_repeats = 5
outer_cv = RepeatedStratifiedKFold(n_splits=num_outcv, n_repeats=num_repeats, random_state=42)
inner_cv = StratifiedKFold(n_splits=num_inncv, shuffle=True, random_state=42)

final_scores = []
threshold = 0.5

# ROC 曲线累积
mean_fpr = np.linspace(0, 1, 100)
tprs = []
auc_values = []

# 校准数据
calibrated_probs, uncalibrated_probs, true_labels = [], [], []

# 池化预测（CI 计算用）
uncalibrated_preds, calibrated_preds = [], []
ev_y_true_all, ev_y_proba_all, ev_y_pred_all = np.array([]), np.array([]), np.array([], dtype=int)

# SHAP 值收集
shap_records = {}


def objective(trial, x_train, y_train):
    penalty = trial.suggest_categorical('penalty', ['l1', 'l2', 'none'])

    params = {
        'random_state': 42,
        'max_iter': 5000,
        'class_weight': 'balanced',
        'tol': 1e-3,
    }

    if penalty == 'l1':
        params.update({
            'penalty': 'l1',
            'C': trial.suggest_float('C_l1', 0.1, 10.0, log=True),
            'solver': trial.suggest_categorical('solver_l1', ['liblinear', 'saga']),
        })
    elif penalty == 'l2':
        params.update({
            'penalty': 'l2',
            'C': trial.suggest_float('C_l2', 0.1, 10.0, log=True),
            'solver': trial.suggest_categorical('solver_l2', ['lbfgs', 'newton-cg', 'sag', 'saga']),
        })
    else:
        params.update({
            'penalty': None,
            'solver': trial.suggest_categorical('solver_none', ['lbfgs', 'newton-cg', 'sag', 'saga']),
        })

    metrics = {'roc_auc': []}

    for train_index, valid_index in inner_cv.split(x_train, y_train):
        x_train_infold, x_invalid_infold = x_train[train_index], x_train[valid_index]
        y_train_infold = y_train[train_index]
        y_invalid_infold = y_train[valid_index]

        scaler = StandardScaler()
        x_train_scaled_infold = scaler.fit_transform(x_train_infold)
        x_invalid_infold = scaler.transform(x_invalid_infold)

        model = LogisticRegression(**params)
        model.fit(x_train_scaled_infold, y_train_infold)

        y_proba_infold = model.predict_proba(x_invalid_infold)[:, 1]
        metrics['roc_auc'].append(roc_auc_score(y_invalid_infold, y_proba_infold))

    mean_auc = np.mean(metrics['roc_auc'])
    trial.set_user_attr("roc_auc_mean", mean_auc)
    trial.set_user_attr("roc_auc_std", np.std(metrics['roc_auc']))
    return mean_auc


# 外部交叉验证
for fold, (out_train_index, out_valid_index) in enumerate(outer_cv.split(X_raw, Y_raw)):
    X_train_raw, X_val_raw = X_raw[out_train_index], X_raw[out_valid_index]
    y_train_raw, y_val = Y_raw[out_train_index], Y_raw[out_valid_index]

    study = optuna.create_study(direction='maximize')
    study.optimize(lambda trial: objective(trial, X_train_raw, y_train_raw),
                   n_trials=100, show_progress_bar=True)

    best_params = study.best_params
    best_penalty = best_params['penalty']

    # 根据选中的 penalty 提取对应的 C 和 solver
    if best_penalty == 'l1':
        best_C = best_params['C_l1']
        best_solver = best_params['solver_l1']
    elif best_penalty == 'l2':
        best_C = best_params['C_l2']
        best_solver = best_params['solver_l2']
    else:
        best_C = None
        best_solver = best_params['solver_none']

    model_params = {
        'random_state': 42,
        'max_iter': 5000,
        'class_weight': 'balanced',
        'tol': 1e-3,
        'penalty': None if best_penalty == 'none' else best_penalty,
        'solver': best_solver,
    }
    if best_C is not None:
        model_params['C'] = best_C

    best_model = LogisticRegression(**model_params)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_raw)
    X_val_scaled = scaler.transform(X_val_raw)

    # 外部验证标准化
    X_val_scaled_ev = scaler.transform(X_raw_ev)
    y_val_ev = Y_raw_ev

    best_trial = study.best_trial
    print(f"inner的最佳指标：")
    print(f'Best penalty: {best_penalty}, Best C: {best_C}, Best solver: {best_solver}')
    print(f"ROC AUC: {best_trial.user_attrs['roc_auc_mean']:.3f} ± {best_trial.user_attrs['roc_auc_std']:.3f}")

    best_model.fit(X_train_scaled, y_train_raw)

    # 未校准预测
    y_proba = best_model.predict_proba(X_val_scaled)[:, 1]
    y_pred = (y_proba >= threshold).astype(int)

    test_auc = roc_auc_score(y_val, y_proba)
    test_accuracy = accuracy_score(y_val, y_pred)
    test_f1 = f1_score(y_val, y_pred)
    test_recall = recall_score(y_val, y_pred)
    test_precision = precision_score(y_val, y_pred)
    test_brier_raw = brier_score_loss(y_val, y_proba)

    # ROC 数据
    fpr, tpr, _ = roc_curve(y_val, y_proba)
    tprs.append(np.interp(mean_fpr, fpr, tpr))
    auc_values.append(auc(fpr, tpr))

    # Platt 校准
    calibrated = CalibratedClassifierCV(best_model, method='sigmoid', cv=5)
    calibrated.fit(X_train_scaled, y_train_raw)
    cal_probs = calibrated.predict_proba(X_val_scaled)[:, 1]
    cal_pred = (cal_probs >= threshold).astype(int)

    brier_calibrated = brier_score_loss(y_val, cal_probs)

    calibrated_probs.extend(cal_probs)
    uncalibrated_probs.extend(y_proba)
    true_labels.extend(y_val)

    cal_auc = roc_auc_score(y_val, cal_probs)
    cal_accuracy = accuracy_score(y_val, cal_pred)
    cal_f1 = f1_score(y_val, cal_pred)
    cal_recall = recall_score(y_val, cal_pred)
    cal_precision = precision_score(y_val, cal_pred)

    # 外部验证
    ev_cal_probs = best_model.predict_proba(X_val_scaled_ev)[:, 1]
    ev_cal_pred = (ev_cal_probs >= threshold).astype(int)

    ev_auc = roc_auc_score(y_val_ev, ev_cal_probs)
    ev_accuracy = accuracy_score(y_val_ev, ev_cal_pred)
    ev_f1 = f1_score(y_val_ev, ev_cal_pred)
    ev_recall = recall_score(y_val_ev, ev_cal_pred)
    ev_precision = precision_score(y_val_ev, ev_cal_pred)

    # SHAP 值计算（LinearExplainer）
    explainer = shap.LinearExplainer(best_model, X_train_scaled)
    shap_values = explainer.shap_values(X_val_scaled)
    for idx, sample_idx in enumerate(out_valid_index):
        if sample_idx not in shap_records:
            shap_records[sample_idx] = []
        shap_records[sample_idx].append((fold, shap_values[idx]))

    # 池化累积
    uncalibrated_preds.append(y_pred)
    calibrated_preds.append(cal_pred)
    ev_y_true_all = np.concatenate([ev_y_true_all, y_val_ev])
    ev_y_proba_all = np.concatenate([ev_y_proba_all, ev_cal_probs])
    ev_y_pred_all = np.concatenate([ev_y_pred_all, ev_cal_pred])

    final_scores.append({
        'fold': fold + 1,
        'best_penalty': best_penalty,
        'best_C': best_C,
        'best_solver': best_solver,
        'test_accuracy': test_accuracy,
        'test_f1': test_f1,
        'test_recall': test_recall,
        'test_precision': test_precision,
        'test_roc_auc': test_auc,
        'test_brier_raw': test_brier_raw,
        'cal_accuracy': cal_accuracy,
        'cal_f1': cal_f1,
        'cal_recall': cal_recall,
        'cal_precision': cal_precision,
        'cal_roc_auc': cal_auc,
        'cal_brier': brier_calibrated,
        'ev_accuracy': ev_accuracy,
        'ev_f1': ev_f1,
        'ev_recall': ev_recall,
        'ev_precision': ev_precision,
        'ev_roc_auc': ev_auc,
    })
    print(f"Fold {fold + 1} | AUC: {test_auc:.3f} | F1: {test_f1:.3f} | EV AUC: {ev_auc:.3f}")

# ============================================================
# 最终输出
# ============================================================
print("\nFinal Model Metrics (mean ± std across folds):")
for metric in ['accuracy', 'f1', 'recall', 'precision', 'roc_auc', 'brier_raw']:
    key_name = f'test_{metric}'
    values = [m[key_name] for m in final_scores]
    print(f"  Test {metric.upper():<9}: {np.mean(values):.4f} ± {np.std(values):.4f}")
print("  ---")
for metric in ['accuracy', 'f1', 'recall', 'precision', 'roc_auc', 'brier']:
    key_name = f'cal_{metric}'
    values = [m[key_name] for m in final_scores]
    print(f"  Cal  {metric.upper():<9}: {np.mean(values):.4f} ± {np.std(values):.4f}")
print("  --- 外部验证")
for metric in ['accuracy', 'f1', 'recall', 'precision', 'roc_auc']:
    key_name = f'ev_{metric}'
    values = [m[key_name] for m in final_scores]
    print(f"  EV   {metric.upper():<9}: {np.mean(values):.4f} ± {np.std(values):.4f}")

# ============================================================
# DeLong + Wilson CI
# ============================================================
true_labels_arr = np.array(true_labels)
cal_probs_arr = np.array(calibrated_probs)
uncal_probs_arr = np.array(uncalibrated_probs)
uncal_preds_arr = np.concatenate(uncalibrated_preds).ravel()
cal_preds_arr = np.concatenate(calibrated_preds).ravel()

test_results = compute_all_cis(true_labels_arr, uncal_preds_arr, uncal_probs_arr)
print_ci_report(test_results, title="Test Set — DeLong + Wilson 95% CI")

cal_results = compute_all_cis(true_labels_arr, cal_preds_arr, cal_probs_arr)
print_ci_report(cal_results, title="Calibrated — DeLong + Wilson 95% CI")

if len(ev_y_true_all) > 0:
    ev_results = compute_all_cis(ev_y_true_all, ev_y_pred_all, ev_y_proba_all)
    print_ci_report(ev_results, title="External Validation — DeLong + Wilson 95% CI")

# ============================================================
# 导出 Excel
# ============================================================
df_out = process_scores(final_scores)
df_out = df_out.sort_values('fold').set_index('fold')

excel_path = "lr_baseline_performance.xlsx"
with pd.ExcelWriter(excel_path, engine='xlsxwriter') as writer:
    df_out.to_excel(writer, sheet_name='Performance Metrics')
    worksheet = writer.sheets['Performance Metrics']
    for idx, col in enumerate(df_out.columns):
        max_len = max((df_out[col].astype(str).map(len).max(), len(str(col)))) + 2
        worksheet.set_column(idx, idx, max_len)

    ci_rows = []
    for eval_name, results in [("Test", test_results), ("Calibrated", cal_results),
                                ("External Validation", ev_results)]:
        for metric in ['auroc', 'accuracy', 'recall', 'precision', 'f1']:
            r = results[metric]
            ci_rows.append({
                'Evaluation': eval_name,
                'Metric': metric.upper(),
                'Value': round(r['value'], 4),
                'CI_Lower': round(r['ci_lower'], 4),
                'CI_Upper': round(r['ci_upper'], 4)
            })
    ci_df = pd.DataFrame(ci_rows)
    ci_df.to_excel(writer, sheet_name='95% CI (DeLong+Wilson)', index=False)
    ci_ws = writer.sheets['95% CI (DeLong+Wilson)']
    for idx, col in enumerate(ci_df.columns):
        ci_ws.set_column(idx, idx, max(len(str(col)), 12))
print(f"数据已成功导出至: {excel_path}")

# ============================================================
# SHAP 后处理与可视化
# ============================================================
sorted_indices = sorted(shap_records.keys())
shap_matrix = np.zeros((len(sorted_indices), len(feature_names)))
for i, sample_idx in enumerate(sorted_indices):
    fold_records = shap_records[sample_idx]
    all_shap = np.array([r[1] for r in fold_records])
    shap_matrix[i] = np.mean(all_shap, axis=0)

scaler_forshow = StandardScaler()
X_raw_forshow = scaler_forshow.fit_transform(X_raw)

shap_explanation = shap.Explanation(
    values=shap_matrix,
    data=X_raw_forshow,
    feature_names=feature_names
)

plt.rcParams.update({
    'font.family': 'Arial',
    'font.size': 12,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.dpi': 600,
    'savefig.bbox': 'tight',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none'
})

fig = plt.figure(figsize=(18, 9), dpi=200, constrained_layout=True)
gs = GridSpec(1, 2, figure=fig, width_ratios=[3.5, 1], wspace=0.06,
              left=0.08, right=0.92, top=0.92, bottom=0.1)
ax1 = fig.add_subplot(gs[0])
ax2 = fig.add_subplot(gs[1])
max_display = 16

cmap = plt.get_cmap('coolwarm').copy()
cmap.set_bad(color='#808080')

shap.plots.beeswarm(shap_explanation, ax=ax1, show=False, color=cmap, max_display=max_display, plot_size=None)
ax1.set_xlabel("SHAP Value (impact on model output)", fontsize=12, labelpad=10)
ax1.set_title("A) Feature Importance Analysis — LR Baseline", fontsize=14, pad=18, loc='center')
ax1.ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
ax1.xaxis.get_offset_text().set_size(10)

shap.plots.bar(shap_explanation, ax=ax2, show=False, max_display=max_display)
for bar in ax2.patches:
    bar.set_facecolor('#6086d1')
for text in ax2.texts:
    text.set_fontsize(8)
    text.set_color('#333333')

ax2.grid(False)
ax2.spines[['right', 'top']].set_visible(False)
ax2.set_ylabel('')
ax2.set_xlabel("Mean |SHAP value|", fontsize=12, labelpad=10)
ax2.set_title("B) Global Feature Impact — LR Baseline", fontsize=14, pad=18, loc='center')
ax2.tick_params(axis='y', labelleft=False)

fig.set_constrained_layout_pads(w_pad=0.08)
plt.savefig('LR_SHAP_Analysis.tif', dpi=600, pil_kwargs={"compression": "tiff_lzw"})
plt.savefig('LR_SHAP_Analysis.pdf')
plt.savefig('LR_SHAP_Analysis.svg')
plt.show()

# ============================================================
# ROC 曲线
# ============================================================
mean_tpr = np.mean(tprs, axis=0)
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(auc_values)

fig, ax = plt.subplots(figsize=(8, 6), dpi=300)
ax.plot(mean_fpr, mean_tpr, color='#2b8cbe', lw=3,
        label=f'Mean ROC (AUC = {mean_auc:.2f} ± {std_auc:.2f})')
ax.plot([0, 1], [0, 1], linestyle='--', lw=2, color='#636363', label='Random Chance')
ax.set(xlim=[-0.02, 1.02], ylim=[-0.02, 1.02],
       xlabel='False Positive Rate', ylabel='True Positive Rate',
       title='ROC Curve — Logistic Regression Baseline')
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend(loc='lower right', frameon=True, fontsize=10)
plt.tight_layout()
plt.savefig('LR_ROC.tif', dpi=600, pil_kwargs={"compression": "tiff_lzw"})
plt.savefig('LR_ROC.pdf')
plt.savefig('LR_ROC.svg')
plt.show()

# ============================================================
# 校准曲线
# ============================================================
def plot_calibration_curve(y_true, probs, label, color):
    fraction_of_positives, mean_predicted_value = calibration_curve(y_true, probs, n_bins=5)
    plt.plot(mean_predicted_value, fraction_of_positives, "s-", label=label, color=color)

plt.figure(figsize=(10, 8))
plot_calibration_curve(true_labels_arr, uncal_probs_arr, "Uncalibrated", color='#6086d1')
plot_calibration_curve(true_labels_arr, cal_probs_arr, "Calibrated", color='#cb6451')
plt.plot([0, 1], [0, 1], "k--", label="Perfectly calibrated")
plt.xlabel("Mean predicted probability", fontsize=12)
plt.ylabel("Fraction of positives", fontsize=12)
plt.title("Calibration — Logistic Regression Baseline", fontsize=14)
plt.legend()
plt.savefig('LR_Calibration.tif', dpi=600, pil_kwargs={"compression": "tiff_lzw"})
plt.savefig('LR_Calibration.pdf')
plt.savefig('LR_Calibration.svg')
plt.show()
